package com.zuma.miletracker

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class VehiclesActivity : AppCompatActivity() {

    private lateinit var store: Store
    private var vehicles: List<Vehicle> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        store = Store(this)

        findViewById<Button>(R.id.topButton).apply {
            text = getString(R.string.add_vehicle)
            setOnClickListener { startActivity(Intent(this@VehiclesActivity, EditVehicleActivity::class.java)) }
        }
        findViewById<ListView>(R.id.list).setOnItemClickListener { _, _, pos, _ ->
            vehicles.getOrNull(pos)?.let {
                startActivity(Intent(this, EditVehicleActivity::class.java)
                    .putExtra(EditVehicleActivity.EXTRA_ID, it.id))
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }

    override fun onResume() {
        super.onResume()
        vehicles = store.vehicles()
        val km = store.useKm
        val rows = vehicles.map {
            "%s. Odometer %,.1f %s. %d trips. Double tap to edit."
                .format(it.displayName(), Units.distance(it.odometerMeters, km), Units.shortUnit(km),
                    store.tripsFor(it.id).size)
        }
        findViewById<ListView>(R.id.list).adapter =
            ArrayAdapter(this, android.R.layout.simple_list_item_1, rows)
        findViewById<TextView>(R.id.summaryText).text =
            if (vehicles.isEmpty()) "" else "${vehicles.size} vehicle" + (if (vehicles.size == 1) "" else "s")
        findViewById<TextView>(R.id.emptyText).apply {
            visibility = if (vehicles.isEmpty()) View.VISIBLE else View.GONE
            text = "No vehicles yet. Use the Add vehicle button."
        }
    }
}
