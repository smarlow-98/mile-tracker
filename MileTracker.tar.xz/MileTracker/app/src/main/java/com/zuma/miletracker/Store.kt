package com.zuma.miletracker

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

const val METERS_PER_MILE = 1609.344
const val METERS_PER_KM = 1000.0

data class Vehicle(
    val id: String,
    var year: Int,
    var make: String,
    var model: String,
    var nickname: String,
    var odometerMeters: Double
) {
    fun displayName(): String {
        val base = "$year $make $model"
        return if (nickname.isBlank()) base else "$nickname, $base"
    }

    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("year", year).put("make", make).put("model", model)
        .put("nickname", nickname).put("odometerMeters", odometerMeters)

    companion object {
        fun fromJson(o: JSONObject) = Vehicle(
            o.getString("id"), o.getInt("year"), o.getString("make"), o.getString("model"),
            o.optString("nickname", ""), o.optDouble("odometerMeters", 0.0)
        )
    }
}

data class Trip(
    val id: String,
    val vehicleId: String,
    val startMillis: Long,
    val endMillis: Long,
    val meters: Double,
    val purpose: String,
    val maxSpeedMps: Double
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("vehicleId", vehicleId).put("start", startMillis)
        .put("end", endMillis).put("meters", meters).put("purpose", purpose)
        .put("maxSpeed", maxSpeedMps)

    companion object {
        fun fromJson(o: JSONObject) = Trip(
            o.getString("id"), o.getString("vehicleId"), o.getLong("start"), o.getLong("end"),
            o.getDouble("meters"), o.optString("purpose", "Personal"), o.optDouble("maxSpeed", 0.0)
        )
    }
}

/** Simple JSON-in-SharedPreferences storage. Small data, no database needed. */
class Store(context: Context) {
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("miletracker", Context.MODE_PRIVATE)

    // ---------- Settings ----------
    var useKm: Boolean
        get() = prefs.getBoolean("useKm", false)
        set(v) = prefs.edit().putBoolean("useKm", v).apply()

    var speakEachUnit: Boolean
        get() = prefs.getBoolean("speakEach", true)
        set(v) = prefs.edit().putBoolean("speakEach", v).apply()

    var keepScreenOn: Boolean
        get() = prefs.getBoolean("keepScreen", false)
        set(v) = prefs.edit().putBoolean("keepScreen", v).apply()

    var selectedVehicleId: String?
        get() = prefs.getString("selectedVehicle", null)
        set(v) = prefs.edit().putString("selectedVehicle", v).apply()

    var lastPurpose: Int
        get() = prefs.getInt("lastPurpose", 0)
        set(v) = prefs.edit().putInt("lastPurpose", v).apply()

    // ---------- Vehicles ----------
    fun vehicles(): MutableList<Vehicle> {
        val arr = JSONArray(prefs.getString("vehicles", "[]"))
        return MutableList(arr.length()) { Vehicle.fromJson(arr.getJSONObject(it)) }
    }

    private fun saveVehicles(list: List<Vehicle>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        prefs.edit().putString("vehicles", arr.toString()).commit()
    }

    fun vehicle(id: String?): Vehicle? = vehicles().firstOrNull { it.id == id }

    fun upsertVehicle(v: Vehicle) {
        val list = vehicles()
        val i = list.indexOfFirst { it.id == v.id }
        if (i >= 0) list[i] = v else list.add(v)
        saveVehicles(list)
    }

    fun deleteVehicle(id: String) {
        saveVehicles(vehicles().filter { it.id != id })
        saveTrips(trips().filter { it.vehicleId != id })
        if (selectedVehicleId == id) selectedVehicleId = vehicles().firstOrNull()?.id
    }

    fun addMetersToVehicle(id: String, meters: Double) {
        val v = vehicle(id) ?: return
        v.odometerMeters += meters
        upsertVehicle(v)
    }

    // ---------- Trips ----------
    fun trips(): MutableList<Trip> {
        val arr = JSONArray(prefs.getString("trips", "[]"))
        return MutableList(arr.length()) { Trip.fromJson(arr.getJSONObject(it)) }
    }

    private fun saveTrips(list: List<Trip>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        prefs.edit().putString("trips", arr.toString()).commit()
    }

    fun tripsFor(vehicleId: String): List<Trip> =
        trips().filter { it.vehicleId == vehicleId }.sortedByDescending { it.startMillis }

    fun addTrip(t: Trip) {
        val list = trips()
        list.add(t)
        saveTrips(list)
    }

    fun deleteTrip(id: String, alsoSubtractFromOdometer: Boolean) {
        val list = trips()
        val t = list.firstOrNull { it.id == id } ?: return
        saveTrips(list.filter { it.id != id })
        if (alsoSubtractFromOdometer) addMetersToVehicle(t.vehicleId, -t.meters)
    }

    // ---------- In-progress trip (crash/kill safety) ----------
    fun saveActiveTrip(vehicleId: String, start: Long, meters: Double, purpose: String, maxSpeed: Double) {
        prefs.edit()
            .putString("active", JSONObject()
                .put("vehicleId", vehicleId).put("start", start).put("meters", meters)
                .put("purpose", purpose).put("maxSpeed", maxSpeed).toString())
            .apply()
    }

    fun activeTrip(): JSONObject? = prefs.getString("active", null)?.let {
        try { JSONObject(it) } catch (e: Exception) { null }
    }

    fun clearActiveTrip() {
        prefs.edit().remove("active").commit()
    }

    // ---------- Model list cache from online lookup ----------
    fun cachedModels(make: String, year: Int): List<String>? {
        val s = prefs.getString("models|$make|$year", null) ?: return null
        val arr = JSONArray(s)
        return List(arr.length()) { arr.getString(it) }
    }

    fun cacheModels(make: String, year: Int, models: List<String>) {
        val arr = JSONArray()
        models.forEach { arr.put(it) }
        prefs.edit().putString("models|$make|$year", arr.toString()).apply()
    }

    companion object {
        fun newId(): String = UUID.randomUUID().toString()
    }
}

object Units {
    fun distance(meters: Double, km: Boolean): Double =
        if (km) meters / METERS_PER_KM else meters / METERS_PER_MILE

    fun unitName(km: Boolean, plural: Boolean = true): String =
        if (km) (if (plural) "kilometers" else "kilometer") else (if (plural) "miles" else "mile")

    fun shortUnit(km: Boolean) = if (km) "km" else "mi"

    fun speed(mps: Double, km: Boolean): Double = if (km) mps * 3.6 else mps * 2.2369363

    fun speedUnit(km: Boolean) = if (km) "kilometers per hour" else "miles per hour"

    fun speedShort(km: Boolean) = if (km) "km/h" else "mph"

    fun duration(ms: Long): String {
        val totalSec = (ms / 1000).coerceAtLeast(0)
        val h = totalSec / 3600
        val m = (totalSec % 3600) / 60
        val s = totalSec % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
    }

    fun durationSpoken(ms: Long): String {
        val totalMin = (ms / 60000).coerceAtLeast(0)
        val h = totalMin / 60
        val m = totalMin % 60
        val parts = mutableListOf<String>()
        if (h > 0) parts.add("$h hour" + if (h == 1L) "" else "s")
        parts.add("$m minute" + if (m == 1L) "" else "s")
        return parts.joinToString(" ")
    }
}
