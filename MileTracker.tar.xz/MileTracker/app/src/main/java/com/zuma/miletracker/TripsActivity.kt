package com.zuma.miletracker

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class TripsActivity : AppCompatActivity() {

    private lateinit var store: Store
    private var trips: List<Trip> = emptyList()
    private val dateFmt = SimpleDateFormat("EEE, MMM d yyyy, h:mm a", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        store = Store(this)

        findViewById<Button>(R.id.topButton).apply {
            text = getString(R.string.export_csv)
            setOnClickListener { exportCsv() }
        }
        findViewById<ListView>(R.id.list).setOnItemClickListener { _, _, pos, _ ->
            trips.getOrNull(pos)?.let { confirmDelete(it) }
        }
        load()
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }

    private fun load() {
        val v = store.vehicle(store.selectedVehicleId)
        title = if (v != null) "Trips: ${v.displayName()}" else getString(R.string.trips_title)
        trips = if (v != null) store.tripsFor(v.id) else emptyList()
        val km = store.useKm

        val rows = trips.map { t ->
            "%s. %.2f %s, %s, %s. Double tap to delete.".format(
                dateFmt.format(Date(t.startMillis)),
                Units.distance(t.meters, km), Units.unitName(km),
                Units.durationSpoken(t.endMillis - t.startMillis), t.purpose)
        }
        findViewById<ListView>(R.id.list).adapter =
            ArrayAdapter(this, android.R.layout.simple_list_item_1, rows)

        // Totals: this month, this year, all time, plus business miles this year.
        val cal = Calendar.getInstance()
        val year = cal.get(Calendar.YEAR)
        val month = cal.get(Calendar.MONTH)
        fun inYear(t: Trip) = Calendar.getInstance().apply { timeInMillis = t.startMillis }.get(Calendar.YEAR) == year
        fun inMonth(t: Trip) = Calendar.getInstance().apply { timeInMillis = t.startMillis }
            .let { it.get(Calendar.YEAR) == year && it.get(Calendar.MONTH) == month }
        val u = Units.shortUnit(km)
        val monthTotal = Units.distance(trips.filter(::inMonth).sumOf { it.meters }, km)
        val yearTotal = Units.distance(trips.filter(::inYear).sumOf { it.meters }, km)
        val bizYear = Units.distance(trips.filter { inYear(it) && it.purpose == "Business" }.sumOf { it.meters }, km)
        val all = Units.distance(trips.sumOf { it.meters }, km)
        findViewById<TextView>(R.id.summaryText).text =
            "This month %.1f %s. This year %.1f %s, of which business %.1f %s. All trips %.1f %s, %d trips."
                .format(monthTotal, u, yearTotal, u, bizYear, u, all, u, trips.size)

        findViewById<TextView>(R.id.emptyText).apply {
            visibility = if (trips.isEmpty()) View.VISIBLE else View.GONE
            text = "No trips yet for this vehicle."
        }
    }

    private fun confirmDelete(t: Trip) {
        AlertDialog.Builder(this)
            .setTitle("Delete this trip?")
            .setMessage(dateFmt.format(Date(t.startMillis)))
            .setPositiveButton("Delete and subtract from odometer") { _, _ ->
                store.deleteTrip(t.id, true); load()
            }
            .setNeutralButton("Delete, keep odometer") { _, _ ->
                store.deleteTrip(t.id, false); load()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun exportCsv() {
        val all = store.trips().sortedBy { it.startMillis }
        if (all.isEmpty()) { Toast.makeText(this, "No trips to export.", Toast.LENGTH_LONG).show(); return }
        val vehicles = store.vehicles().associateBy { it.id }
        val iso = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        val sb = StringBuilder("Vehicle,Year,Make,Model,Start,End,Miles,Kilometers,Minutes,Purpose,Max mph\n")
        for (t in all) {
            val v = vehicles[t.vehicleId]
            fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
            sb.append(listOf(
                q(v?.nickname?.ifBlank { null } ?: v?.displayName() ?: ""),
                (v?.year ?: "").toString(), q(v?.make ?: ""), q(v?.model ?: ""),
                iso.format(Date(t.startMillis)), iso.format(Date(t.endMillis)),
                "%.2f".format(Locale.US, t.meters / METERS_PER_MILE),
                "%.2f".format(Locale.US, t.meters / METERS_PER_KM),
                ((t.endMillis - t.startMillis) / 60000).toString(),
                q(t.purpose),
                "%.0f".format(Locale.US, Units.speed(t.maxSpeedMps, false))
            ).joinToString(",")).append('\n')
        }
        val dir = File(cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, "mile-tracker-trips.csv")
        file.writeText(sb.toString())
        val uri = FileProvider.getUriForFile(this, "$packageName.files", file)
        val send = Intent(Intent.ACTION_SEND)
            .setType("text/csv")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .putExtra(Intent.EXTRA_SUBJECT, "Mile Tracker trips")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(send, "Share trips"))
    }
}
