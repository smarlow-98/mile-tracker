package com.zuma.miletracker

import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Calendar
import org.json.JSONObject

/**
 * Built-in list of makes and models sold in the US from 1990 to now, with the
 * model years each was offered. When the phone is online, the app also asks the
 * free US government (NHTSA) vehicle database for the exact model list for the
 * chosen make and year, so the list is complete.
 */
object VehicleCatalog {

    const val FIRST_YEAR = 1990
    val LAST_YEAR: Int get() = Calendar.getInstance().get(Calendar.YEAR) + 1
    const val OTHER = "Other (type it in)"

    // Make=Model:years;Model:years   years like 1990-2005, 2010- (still sold), or several joined with commas
    private const val DATA = """
Acura=CL:1997-2003;ILX:2013-2022;Integra:1990-2001,2023-;Legend:1990-1995;MDX:2001-;NSX:1991-2005,2017-2022;RDX:2007-;RL:1996-2012;RLX:2014-2020;RSX:2002-2006;SLX:1996-1999;TL:1996-2014;TLX:2015-;TSX:2004-2014;Vigor:1992-1994;ZDX:2010-2013,2024-
Alfa Romeo=164:1991-1995;4C:2015-2020;Giulia:2017-;Spider:1990-1994;Stelvio:2018-;Tonale:2023-
Audi=100:1990-1994;80:1990-1992;90:1993-1995;A3:2006-;A4:1996-;A5:2008-;A6:1995-;A7:2012-;A8:1997-;Cabriolet:1994-1998;e-tron:2019-2023;Q3:2015-;Q4 e-tron:2022-;Q5:2009-;Q7:2007-;Q8:2019-;R8:2008-2023;RS 5:2013-;S4:1992-;S5:2008-;TT:2000-2023
BMW=1 Series:2008-2013;2 Series:2014-;3 Series:1990-;4 Series:2014-;5 Series:1990-;6 Series:1990,2004-2019;7 Series:1990-;8 Series:1991-1997,2019-;i3:2014-2021;i4:2022-;i7:2023-;iX:2022-;M3:1990-1991,1995-;M5:1991-1993,2000-;X1:2013-;X2:2018-;X3:2004-;X4:2015-;X5:2000-;X6:2008-;X7:2019-;Z3:1996-2002;Z4:2003-2016,2019-
Buick=Cascada:2016-2019;Century:1990-2005;Enclave:2008-;Encore:2013-2022;Encore GX:2020-;Envision:2016-;Envista:2024-;LaCrosse:2005-2019;LeSabre:1990-2005;Lucerne:2006-2011;Park Avenue:1991-2005;Rainier:2004-2007;Reatta:1990-1991;Regal:1990-2004,2011-2020;Rendezvous:2002-2007;Riviera:1990-1993,1995-1999;Roadmaster:1991-1996;Skylark:1990-1998;Terraza:2005-2007;Verano:2012-2017
Cadillac=Allante:1990-1993;ATS:2013-2019;Brougham:1990-1992;Catera:1997-2001;CT4:2020-;CT5:2020-;CT6:2016-2020;CTS:2003-2019;DeVille:1990-2005;DTS:2006-2011;Eldorado:1990-2002;Escalade:1999-;Escalade ESV:2003-;Escalade EXT:2002-2013;Fleetwood:1990-1996;Lyriq:2023-;Optiq:2025-;Seville:1990-2004;SRX:2004-2016;STS:2005-2011;XLR:2004-2009;XT4:2019-;XT5:2017-;XT6:2020-;XTS:2013-2019
Chevrolet=Astro:1990-2005;Avalanche:2002-2013;Aveo:2004-2011;Beretta:1990-1996;Blazer:1990-2005,2019-;Bolt EUV:2022-2023;Bolt EV:2017-2023,2027-;Camaro:1990-2002,2010-2024;Caprice:1990-1996;Captiva Sport:2012-2015;Cavalier:1990-2005;Cobalt:2005-2010;Colorado:2004-2012,2015-;Corsica:1990-1996;Corvette:1990-;Cruze:2011-2019;Equinox:2005-;Express:1996-;HHR:2006-2011;Impala:1994-1996,2000-2020;Lumina:1990-2001;Malibu:1997-2025;Monte Carlo:1995-2007;Prizm:1998-2002;S-10:1990-2004;Silverado 1500:1999-;Silverado 2500HD:2001-;Silverado 3500HD:2001-;Sonic:2012-2020;Spark:2013-2022;SS:2014-2017;SSR:2003-2006;Suburban:1990-;Tahoe:1995-;Tracker:1999-2004;TrailBlazer:2002-2009,2021-;Traverse:2009-;Trax:2015-;Uplander:2005-2008;Venture:1997-2005;Volt:2011-2019;C/K 1500:1990-1999;Blazer EV:2024-;Equinox EV:2024-;Silverado EV:2024-
Chrysler=200:2011-2017;300:2005-2023;300M:1999-2004;Aspen:2007-2009;Cirrus:1995-2000;Concorde:1993-2004;Crossfire:2004-2008;Imperial:1990-1993;LeBaron:1990-1995;LHS:1994-1997,1999-2001;New Yorker:1990-1996;Pacifica:2004-2008,2017-;PT Cruiser:2001-2010;Sebring:1995-2010;Town & Country:1990-2016;Voyager:2000-2003,2020-
Dodge=Avenger:1995-2000,2008-2014;Caliber:2007-2012;Caravan:1990-2007;Challenger:2008-2023;Charger:2006-2023,2024-;Dakota:1990-2011;Dart:2013-2016;Durango:1998-2009,2011-;Dynasty:1990-1993;Grand Caravan:1990-2020;Hornet:2023-;Intrepid:1993-2004;Journey:2009-2020;Magnum:2005-2008;Neon:1995-2005;Nitro:2007-2011;Ram 1500:1994-2010;Ram 2500:1994-2010;Ram Van:1990-2003;Shadow:1990-1994;Spirit:1990-1995;Stealth:1991-1996;Stratus:1995-2006;Viper:1992-2010,2013-2017
Eagle=Summit:1990-1996;Talon:1990-1998;Vision:1993-1997
Fiat=124 Spider:2017-2020;500:2012-2019,2024-;500L:2014-2020;500X:2016-2023
Ford=Aerostar:1990-1997;Aspire:1994-1997;Bronco:1990-1996,2021-;Bronco Sport:2021-;C-Max:2013-2018;Contour:1995-2000;Crown Victoria:1992-2011;E-Series Van:1990-;EcoSport:2018-2022;Edge:2007-2024;Escape:2001-;Escort:1990-2003;Excursion:2000-2005;Expedition:1997-;Explorer:1991-;Explorer Sport Trac:2001-2010;F-150:1990-;F-150 Lightning:2022-;F-250:1990-;F-350:1990-;Festiva:1990-1993;Fiesta:2011-2019;Five Hundred:2005-2007;Flex:2009-2019;Focus:2000-2018;Freestar:2004-2007;Freestyle:2005-2007;Fusion:2006-2020;GT:2005-2006,2017-2022;Maverick:2022-;Mustang:1990-;Mustang Mach-E:2021-;Probe:1990-1997;Ranger:1990-2011,2019-;Taurus:1990-2019;Taurus X:2008-2009;Tempo:1990-1994;Thunderbird:1990-1997,2002-2005;Transit:2015-;Transit Connect:2010-2023;Windstar:1995-2003
Genesis=G70:2019-;G80:2017-;G90:2017-;GV60:2023-;GV70:2022-;GV80:2021-
Geo=Metro:1990-1997;Prizm:1990-1997;Storm:1990-1993;Tracker:1990-1997
GMC=Acadia:2007-;Canyon:2004-2012,2015-;Envoy:1998-2000,2002-2009;Hummer EV:2022-;Jimmy:1990-2001;Safari:1990-2005;Savana:1996-;Sierra 1500:1999-;Sierra 2500HD:2001-;Sierra 3500HD:2001-;Sonoma:1991-2004;Suburban:1990-1999;Syclone:1991;Terrain:2010-;Typhoon:1992-1993;Yukon:1992-;Yukon XL:2000-;Sierra EV:2024-
Honda=Accord:1990-;Civic:1990-;Civic del Sol:1993-1997;Clarity:2017-2021;CR-V:1997-;CR-Z:2011-2016;Crosstour:2010-2015;Element:2003-2011;Fit:2007-2020;HR-V:2016-;Insight:2000-2006,2010-2014,2019-2022;Odyssey:1995-;Passport:1994-2002,2019-;Pilot:2003-;Prelude:1990-2001,2026-;Prologue:2024-;Ridgeline:2006-2014,2017-;S2000:2000-2009
Hummer=H1:1992-2006;H2:2003-2009;H3:2006-2010
Hyundai=Accent:1995-2022;Azera:2006-2017;Elantra:1992-;Entourage:2007-2009;Equus:2011-2016;Excel:1990-1994;Genesis:2009-2016;Ioniq:2017-2022;Ioniq 5:2022-;Ioniq 6:2023-;Kona:2018-;Palisade:2020-;Santa Cruz:2022-;Santa Fe:2001-;Scoupe:1991-1995;Sonata:1990-;Tiburon:1997-2008;Tucson:2005-;Veloster:2012-2022;Venue:2020-;Veracruz:2007-2012;XG350:2002-2005
Infiniti=EX35:2008-2012;FX35:2003-2012;G20:1991-1996,1999-2002;G35:2003-2008;G37:2008-2013;I30:1996-2001;J30:1993-1997;JX35:2013;M30:1990-1992;M35:2006-2010;M37:2011-2013;Q45:1990-2006;Q50:2014-;Q60:2014-2022;Q70:2014-2019;QX4:1997-2003;QX50:2014-;QX55:2022-2025;QX56:2004-2013;QX60:2014-;QX80:2014-
Isuzu=Amigo:1990-1994,1998-2000;Ascender:2003-2008;Axiom:2002-2004;Hombre:1996-2000;Impulse:1990-1992;Pickup:1990-1995;Rodeo:1991-2004;Trooper:1990-2002;i-Series:2006-2008
Jaguar=E-Pace:2018-2024;F-Pace:2017-;F-Type:2014-2024;I-Pace:2019-2024;S-Type:2000-2008;X-Type:2002-2008;XE:2017-2020;XF:2009-2024;XJ:1990-2019;XK:1997-2015
Jeep=Cherokee:1990-2001,2014-2023;Commander:2006-2010;Compass:2007-;Gladiator:2020-;Grand Cherokee:1993-;Grand Wagoneer:1990-1991,2022-;Liberty:2002-2012;Patriot:2007-2017;Renegade:2015-2023;Wagoneer:2022-;Wagoneer S:2024-;Wrangler:1990-
Kia=Amanti:2004-2009;Borrego:2009;Cadenza:2014-2020;Carnival:2022-;EV6:2022-;EV9:2024-;Forte:2010-2024;K4:2025-;K5:2021-;K900:2015-2020;Niro:2017-;Optima:2001-2020;Rio:2001-2023;Rondo:2007-2010;Sedona:2002-2021;Seltos:2021-;Sephia:1994-2001;Sorento:2003-;Soul:2010-;Spectra:2000-2009;Sportage:1995-2002,2005-;Stinger:2018-2023;Telluride:2020-
Land Rover=Defender:1993-1997,2020-;Discovery:1994-2004,2017-;Discovery Sport:2015-;Freelander:2002-2005;LR2:2008-2015;LR3:2005-2009;LR4:2010-2016;Range Rover:1990-;Range Rover Evoque:2012-;Range Rover Sport:2006-;Range Rover Velar:2018-
Lexus=CT 200h:2011-2017;ES:1990-;GS:1993-2020;GX:2003-;HS 250h:2010-2012;IS:2001-;LC:2018-;LFA:2012;LS:1990-;LX:1996-;NX:2015-;RC:2015-;RX:1999-;RZ:2023-;SC:1992-2000,2002-2010;TX:2024-;UX:2019-
Lincoln=Aviator:2003-2005,2020-;Blackwood:2002;Continental:1990-2002,2017-2020;Corsair:2020-;LS:2000-2006;Mark LT:2006-2008;Mark VII:1990-1992;Mark VIII:1993-1998;MKC:2015-2019;MKS:2009-2016;MKT:2010-2019;MKX:2007-2018;MKZ:2007-2020;Nautilus:2019-;Navigator:1998-;Town Car:1990-2011;Zephyr:2006
Lucid=Air:2022-;Gravity:2025-
Mazda=323:1990-1994;626:1990-2002;929:1990-1995;B-Series:1990-2009;CX-3:2016-2021;CX-30:2020-;CX-5:2013-;CX-50:2023-;CX-7:2007-2012;CX-70:2025-;CX-9:2007-2023;CX-90:2024-;Mazda2:2011-2014;Mazda3:2004-;Mazda5:2012-2015;Mazda6:2003-2021;Millenia:1995-2002;MPV:1990-1998,2000-2006;MX-3:1992-1995;MX-30:2022-2023;MX-5 Miata:1990-;MX-6:1990-1997;Navajo:1991-1994;Protege:1990-2003;RX-7:1990-1995;RX-8:2004-2011;Tribute:2001-2011
Mercedes-Benz=A-Class:2019-2022;C-Class:1994-;CL-Class:1998-2014;CLA:2014-;CLK:1998-2009;CLS:2006-;E-Class:1994-;EQB:2022-;EQE:2023-;EQS:2022-;G-Class:2002-;GL-Class:2007-2016;GLA:2015-;GLB:2020-;GLC:2016-;GLE:2016-;GLK:2010-2015;GLS:2017-;M-Class:1998-2015;R-Class:2006-2013;S-Class:1990-;SL:1990-;SLK:1998-2016;SLC:2017-2020;Sprinter:2010-;Metris:2016-2023;190E:1990-1993
Mercury=Capri:1991-1994;Cougar:1990-1997,1999-2002;Grand Marquis:1990-2011;Marauder:2003-2004;Mariner:2005-2011;Milan:2006-2011;Montego:2005-2007;Monterey:2004-2007;Mountaineer:1997-2010;Mystique:1995-2000;Sable:1990-2005,2008-2009;Topaz:1990-1994;Tracer:1991-1999;Villager:1993-2002
Mini=Clubman:2008-2024;Convertible:2005-;Cooper:2002-;Countryman:2011-;Paceman:2013-2016
Mitsubishi=3000GT:1991-1999;Diamante:1992-2004;Eclipse:1990-2012;Eclipse Cross:2018-;Endeavor:2004-2011;Galant:1990-2012;i-MiEV:2012-2017;Lancer:2002-2017;Mirage:1990-2002,2014-2024;Montero:1990-2006;Montero Sport:1997-2004;Outlander:2003-;Outlander Sport:2011-2024;Raider:2006-2009
Nissan=200SX:1995-1998;240SX:1990-1998;300ZX:1990-1996;350Z:2003-2009;370Z:2009-2020;Altima:1993-;Armada:2004-;Cube:2009-2014;Frontier:1998-;GT-R:2009-2024;Juke:2011-2017;Kicks:2018-;Leaf:2011-;Maxima:1990-2023;Murano:2003-;NV200:2013-2021;NX:1991-1993;Pathfinder:1990-;Pickup:1990-1997;Quest:1993-2017;Rogue:2008-;Sentra:1990-;Stanza:1990-1992;Titan:2004-2024;Versa:2007-;Xterra:2000-2015;Z:2023-;Ariya:2023-
Oldsmobile=Achieva:1992-1998;Alero:1999-2004;Aurora:1995-2003;Bravada:1991-2004;Custom Cruiser:1990-1992;Cutlass:1997-1999;Cutlass Ciera:1990-1996;Cutlass Supreme:1990-1997;Eighty-Eight:1990-1999;Intrigue:1998-2002;Ninety-Eight:1990-1996;Silhouette:1990-2004;Toronado:1990-1992
Plymouth=Acclaim:1990-1995;Breeze:1996-2000;Colt:1990-1994;Grand Voyager:1990-2000;Laser:1990-1994;Neon:1995-2001;Prowler:1997-2001;Sundance:1990-1994;Voyager:1990-2000
Pontiac=Aztek:2001-2005;Bonneville:1990-2005;Firebird:1990-2002;G3:2009-2010;G5:2007-2009;G6:2005-2010;G8:2008-2009;Grand Am:1990-2005;Grand Prix:1990-2008;LeMans:1990-1993;Montana:1999-2006;Solstice:2006-2009;Sunbird:1990-1994;Sunfire:1995-2005;Torrent:2006-2009;Trans Sport:1990-1998;Vibe:2003-2010
Polestar=Polestar 1:2020-2021;Polestar 2:2021-;Polestar 3:2025-
Porsche=911:1990-;918 Spyder:2015;928:1990-1995;944:1990-1991;968:1992-1995;Boxster:1997-;Cayenne:2003-;Cayman:2006-;Macan:2015-;Panamera:2010-;Taycan:2020-
Ram=1500:2011-;1500 Classic:2019-;2500:2011-;3500:2011-;Dakota:2011;ProMaster:2014-;ProMaster City:2015-2022
Rivian=R1S:2022-;R1T:2022-;R2:2026-
Saab=9-2X:2005-2006;9-3:1999-2011;9-4X:2011;9-5:1999-2011;9-7X:2005-2009;900:1990-1998;9000:1990-1998
Saturn=Astra:2008-2009;Aura:2007-2009;ION:2003-2007;L-Series:2000-2005;Outlook:2007-2010;Relay:2005-2007;S-Series:1991-2002;Sky:2007-2010;Vue:2002-2010
Scion=FR-S:2013-2016;iA:2016;iM:2016;iQ:2012-2015;tC:2005-2016;xA:2004-2006;xB:2004-2015;xD:2008-2014
Smart=Fortwo:2008-2019
Subaru=Ascent:2019-;Baja:2003-2006;BRZ:2013-;Crosstrek:2013-;Forester:1998-;Impreza:1993-;Justy:1990-1994;Legacy:1990-;Loyale:1990-1994;Outback:1995-;SVX:1992-1997;Tribeca:2006-2014;WRX:2002-;XT:1990-1991;Solterra:2023-
Suzuki=Aerio:2002-2007;Equator:2009-2012;Esteem:1995-2002;Forenza:2004-2008;Grand Vitara:1999-2013;Kizashi:2010-2013;Reno:2005-2008;Samurai:1990-1995;Sidekick:1990-1998;Swift:1990-2001;SX4:2007-2013;Verona:2004-2006;Vitara:1999-2004;XL-7:2002-2009
Tesla=Cybertruck:2024-;Model 3:2017-;Model S:2012-;Model X:2016-;Model Y:2020-;Roadster:2008-2012
Toyota=4Runner:1990-;86:2017-2020;Avalon:1995-2022;bZ4X:2023-;C-HR:2018-2022;Camry:1990-;Celica:1990-2005;Corolla:1990-;Corolla Cross:2022-;Cressida:1990-1992;Crown:2023-;Echo:2000-2005;FJ Cruiser:2007-2014;GR86:2022-;GR Corolla:2023-;Grand Highlander:2024-;Highlander:2001-;Land Cruiser:1990-2021,2024-;Matrix:2003-2013;Mirai:2016-;MR2:1991-1995,2000-2005;Paseo:1992-1997;Pickup:1990-1995;Previa:1991-1997;Prius:2001-;Prius C:2012-2019;Prius V:2012-2017;RAV4:1996-;Sequoia:2001-;Sienna:1998-;Solara:1999-2008;Supra:1990-1998,2020-;T100:1993-1998;Tacoma:1995-;Tercel:1990-1999;Tundra:2000-;Venza:2009-2015,2021-2024;Yaris:2007-2020
Volkswagen=Arteon:2019-2023;Atlas:2018-;Atlas Cross Sport:2020-;Beetle:1998-2019;Cabrio:1995-2002;Cabriolet:1990-1993;CC:2009-2017;Corrado:1990-1994;Eos:2007-2016;EuroVan:1993-2003;Fox:1990-1993;Golf:1990-2021;Golf GTI:1990-;Golf R:2012-;ID.4:2021-;ID. Buzz:2025-;Jetta:1990-;Passat:1990-2022;Phaeton:2004-2006;Rabbit:2006-2009;Routan:2009-2014;Taos:2022-;Tiguan:2009-;Touareg:2004-2017
Volvo=240:1990-1993;740:1990-1992;850:1993-1997;940:1991-1995;960:1992-1997;C30:2008-2013;C40 Recharge:2022-;C70:1998-2013;EX30:2025-;EX90:2025-;S40:2000-2011;S60:2001-;S70:1998-2000;S80:1999-2016;S90:1997-1998,2017-;V40:2000-2004;V50:2005-2011;V60:2015-;V70:1998-2010;V90:1997-1998,2017-;XC40:2019-;XC60:2010-;XC70:2003-2016;XC90:2003-
"""

    private data class Entry(val model: String, val ranges: List<IntRange>)

    private val catalog: Map<String, List<Entry>> by lazy {
        val last = LAST_YEAR
        val map = sortedMapOf<String, List<Entry>>(String.CASE_INSENSITIVE_ORDER)
        DATA.trim().lines().filter { it.contains('=') }.forEach { line ->
            val make = line.substringBefore('=').trim()
            val entries = line.substringAfter('=').split(';').mapNotNull { part ->
                val name = part.substringBefore(':').trim()
                val yearsText = part.substringAfter(':', "")
                if (name.isEmpty()) return@mapNotNull null
                val ranges = yearsText.split(',').mapNotNull { r ->
                    val t = r.trim()
                    when {
                        t.isEmpty() -> null
                        t.endsWith("-") -> t.dropLast(1).toIntOrNull()?.let { it..last }
                        t.contains('-') -> {
                            val a = t.substringBefore('-').toIntOrNull()
                            val b = t.substringAfter('-').toIntOrNull()
                            if (a != null && b != null) a..b else null
                        }
                        else -> t.toIntOrNull()?.let { it..it }
                    }
                }
                Entry(name, ranges)
            }
            map[make] = entries
        }
        map
    }

    fun years(): List<Int> = (LAST_YEAR downTo FIRST_YEAR).toList()

    /** Makes that sold at least one model in the given year, plus "Other". */
    fun makesFor(year: Int): List<String> {
        val list = catalog.filter { (_, models) -> models.any { m -> m.ranges.any { year in it } } }
            .keys.toMutableList()
        list.add(OTHER)
        return list
    }

    /** Models for that make and year from the built-in list. */
    fun modelsFor(make: String, year: Int): List<String> =
        catalog[make].orEmpty().filter { m -> m.ranges.any { year in it } }
            .map { it.model }.sortedWith(String.CASE_INSENSITIVE_ORDER)

    /**
     * Ask NHTSA for the full model list. Runs on a background thread.
     * Returns null when offline or if anything fails.
     */
    fun fetchOnline(make: String, year: Int): List<String>? {
        val types = listOf("passenger car", "truck", "multipurpose passenger vehicle (mpv)")
        val results = sortedSetOf<String>(String.CASE_INSENSITIVE_ORDER)
        var anySuccess = false
        for (type in types) {
            try {
                val url = URL(
                    "https://vpic.nhtsa.dot.gov/api/vehicles/GetModelsForMakeYear/make/" +
                        enc(make) + "/modelyear/" + year + "/vehicletype/" + enc(type) + "?format=json"
                )
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 10000
                try {
                    if (conn.responseCode != 200) continue
                    val body = conn.inputStream.bufferedReader().use { it.readText() }
                    val arr = JSONObject(body).optJSONArray("Results") ?: continue
                    anySuccess = true
                    for (i in 0 until arr.length()) {
                        val name = arr.getJSONObject(i).optString("Model_Name").trim()
                        if (name.isNotEmpty()) results.add(name)
                    }
                } finally {
                    conn.disconnect()
                }
            } catch (e: Exception) {
                // offline or server problem; fall back to built-in list
            }
        }
        return if (anySuccess && results.isNotEmpty()) results.toList() else null
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")
}
