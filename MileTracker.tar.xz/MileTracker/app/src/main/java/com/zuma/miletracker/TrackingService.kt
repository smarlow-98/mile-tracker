package com.zuma.miletracker

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import java.util.Locale

/** Live trip state shared between the service and the screen. */
object TrackerState {
    var tracking = false
    var vehicleId: String? = null
    var purpose = "Personal"
    var startMillis = 0L
    var tripMeters = 0.0
    var speedMps = 0.0
    var maxSpeedMps = 0.0
    var accuracyMeters: Float? = null
    var lastFixElapsed = 0L

    private val listeners = mutableSetOf<() -> Unit>()
    private val main = Handler(Looper.getMainLooper())

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }
    fun changed() { main.post { listeners.toList().forEach { it() } } }

    fun gpsDescription(): String {
        val acc = accuracyMeters
        if (!tracking) return "Off"
        if (acc == null || SystemClock.elapsedRealtime() - lastFixElapsed > 10_000) return "Searching for GPS signal"
        val q = when {
            acc <= 8 -> "Excellent"
            acc <= 15 -> "Good"
            acc <= 30 -> "Fair"
            else -> "Weak"
        }
        return "$q, accurate to about ${acc.toInt()} meters"
    }
}

class TrackingService : Service(), LocationListener, TextToSpeech.OnInitListener {

    companion object {
        const val ACTION_START = "com.zuma.miletracker.START"
        const val ACTION_STOP = "com.zuma.miletracker.STOP"
        const val EXTRA_VEHICLE = "vehicle"
        const val EXTRA_PURPOSE = "purpose"
        private const val CHANNEL = "tracking"
        private const val NOTIF_ID = 42

        // Ignore fixes worse than this (meters).
        private const val MAX_ACCURACY = 35f
        // Below this speed (m/s, about 2 mph) we treat the car as parked, so GPS drift isn't counted.
        private const val MIN_MOVING_SPEED = 0.9
        // Reject impossible jumps (m/s, about 200 mph).
        private const val MAX_SPEED = 90.0

        fun start(ctx: Context, vehicleId: String, purpose: String) {
            val i = Intent(ctx, TrackingService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_VEHICLE, vehicleId)
                .putExtra(EXTRA_PURPOSE, purpose)
            ContextCompat.startForegroundService(ctx, i)
        }

        fun stop(ctx: Context) {
            val i = Intent(ctx, TrackingService::class.java).setAction(ACTION_STOP)
            ctx.startService(i)
        }
    }

    private lateinit var store: Store
    private var lm: LocationManager? = null
    private var last: Location? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var nextAnnounceUnits = 1
    private var lastSaveElapsed = 0L
    private var lastNotifElapsed = 0L
    private var wakeLock: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            if (TrackerState.tracking) {
                // Speed goes to zero if we stop getting fixes.
                if (SystemClock.elapsedRealtime() - TrackerState.lastFixElapsed > 5000) TrackerState.speedMps = 0.0
                TrackerState.changed()
                handler.postDelayed(this, 1000)
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        store = Store(this)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                finishTrip()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                val vid = intent.getStringExtra(EXTRA_VEHICLE)
                if (vid == null) { stopSelf(); return START_NOT_STICKY }
                beginTrip(vid, intent.getStringExtra(EXTRA_PURPOSE) ?: "Personal", null)
            }
            null -> {
                // Restarted by the system after being killed: resume the saved trip.
                val active = store.activeTrip()
                if (active == null) { stopSelf(); return START_NOT_STICKY }
                beginTrip(active.getString("vehicleId"), active.optString("purpose", "Personal"), active)
            }
        }
        return START_STICKY
    }

    @SuppressLint("MissingPermission")
    private fun beginTrip(vehicleId: String, purpose: String, resume: org.json.JSONObject?) {
        val notif = buildNotification()
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
            ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION else 0
        try {
            ServiceCompat.startForeground(this, NOTIF_ID, notif, type)
        } catch (e: Exception) {
            stopSelf()
            return
        }

        if (TrackerState.tracking) return  // already running

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            stopSelf()
            return
        }

        TrackerState.tracking = true
        TrackerState.vehicleId = vehicleId
        TrackerState.purpose = purpose
        TrackerState.startMillis = resume?.optLong("start") ?: System.currentTimeMillis()
        TrackerState.tripMeters = resume?.optDouble("meters", 0.0) ?: 0.0
        TrackerState.maxSpeedMps = resume?.optDouble("maxSpeed", 0.0) ?: 0.0
        TrackerState.speedMps = 0.0
        TrackerState.accuracyMeters = null
        last = null
        val km = store.useKm
        nextAnnounceUnits = Units.distance(TrackerState.tripMeters, km).toInt() + 1

        store.saveActiveTrip(vehicleId, TrackerState.startMillis, TrackerState.tripMeters, purpose, TrackerState.maxSpeedMps)

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MileTracker:trip").apply {
            setReferenceCounted(false)
            acquire(12 * 60 * 60 * 1000L)
        }

        if (tts == null) tts = TextToSpeech(this, this)

        lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        lm?.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this, Looper.getMainLooper())

        handler.post(ticker)
        TrackerState.changed()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.getDefault()
            ttsReady = true
        }
    }

    private fun speak(text: String) {
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_ADD, null, "mt" + SystemClock.elapsedRealtime())
    }

    override fun onLocationChanged(loc: Location) {
        if (!TrackerState.tracking) return
        TrackerState.lastFixElapsed = SystemClock.elapsedRealtime()
        TrackerState.accuracyMeters = if (loc.hasAccuracy()) loc.accuracy else null
        TrackerState.speedMps = if (loc.hasSpeed()) loc.speed.toDouble() else 0.0

        if (!loc.hasAccuracy() || loc.accuracy > MAX_ACCURACY) {
            TrackerState.changed()
            return
        }

        val prev = last
        last = loc
        if (prev != null) {
            val d = prev.distanceTo(loc).toDouble()
            val dt = (loc.time - prev.time) / 1000.0
            val impliedSpeed = if (dt > 0) d / dt else 0.0
            val gpsSpeed = if (loc.hasSpeed()) loc.speed.toDouble() else impliedSpeed
            val moving = gpsSpeed >= MIN_MOVING_SPEED
            if (moving && dt > 0 && impliedSpeed < MAX_SPEED) {
                TrackerState.tripMeters += d
                if (gpsSpeed > TrackerState.maxSpeedMps) TrackerState.maxSpeedMps = gpsSpeed
            }
        }

        // Spoken milestone every mile / kilometer.
        val km = store.useKm
        val units = Units.distance(TrackerState.tripMeters, km)
        if (units >= nextAnnounceUnits) {
            if (store.speakEachUnit) {
                val n = nextAnnounceUnits
                speak("$n ${Units.unitName(km, n != 1)}")
            }
            nextAnnounceUnits = units.toInt() + 1
        }

        val now = SystemClock.elapsedRealtime()
        if (now - lastSaveElapsed > 10_000) {
            lastSaveElapsed = now
            store.saveActiveTrip(TrackerState.vehicleId ?: return, TrackerState.startMillis,
                TrackerState.tripMeters, TrackerState.purpose, TrackerState.maxSpeedMps)
        }
        if (now - lastNotifElapsed > 5_000) {
            lastNotifElapsed = now
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIF_ID, buildNotification())
        }
        TrackerState.changed()
    }

    // Older Android versions call these; keep them so nothing crashes.
    @Deprecated("Deprecated in Java")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {
        speak("GPS was turned off. Distance is paused.")
    }

    private fun finishTrip() {
        if (TrackerState.tracking) {
            lm?.removeUpdates(this)
            val vid = TrackerState.vehicleId
            val meters = TrackerState.tripMeters
            if (vid != null && meters > 10) {
                store.addTrip(Trip(Store.newId(), vid, TrackerState.startMillis, System.currentTimeMillis(),
                    meters, TrackerState.purpose, TrackerState.maxSpeedMps))
                store.addMetersToVehicle(vid, meters)
            }
            val km = store.useKm
            val msg = "Trip stopped. %.1f %s.".format(Units.distance(meters, km), Units.unitName(km))
            if (ttsReady && store.speakEachUnit) speak(msg)
        }
        store.clearActiveTrip()
        TrackerState.tracking = false
        TrackerState.speedMps = 0.0
        TrackerState.accuracyMeters = null
        TrackerState.changed()
        handler.removeCallbacks(ticker)
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        // Give the spoken summary a moment to finish before shutting down speech.
        handler.postDelayed({ if (!TrackerState.tracking) stopSelf() }, 3000)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        lm?.removeUpdates(this)
        tts?.shutdown()
        wakeLock?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW)
            ch.setShowBadge(false)
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(): Notification {
        val km = store.useKm
        val vehicle = store.vehicle(TrackerState.vehicleId)?.displayName() ?: ""
        val text = "%.1f %s · %s".format(
            Units.distance(TrackerState.tripMeters, km), Units.shortUnit(km), vehicle)
        val open = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val stop = PendingIntent.getService(this, 1,
            Intent(this, TrackingService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Tracking trip")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .addAction(0, "Stop trip", stop)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }
}
