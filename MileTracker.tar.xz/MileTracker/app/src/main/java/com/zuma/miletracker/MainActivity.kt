package com.zuma.miletracker

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.materialswitch.MaterialSwitch

class MainActivity : AppCompatActivity() {

    private lateinit var store: Store
    private lateinit var vehicleSpinner: Spinner
    private lateinit var purposeSpinner: Spinner
    private lateinit var startStop: Button
    private lateinit var stateText: TextView
    private lateinit var speedText: TextView
    private lateinit var tripText: TextView
    private lateinit var timeText: TextView
    private lateinit var odometerText: TextView
    private lateinit var gpsText: TextView
    private var vehicles: List<Vehicle> = emptyList()
    private var lastTracking: Boolean? = null

    private val purposes = listOf("Personal", "Business", "Medical", "Charity", "Commute", "Other")

    private val listener: () -> Unit = { refresh() }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (result[Manifest.permission.ACCESS_FINE_LOCATION] == true) {
                startTrip()
            } else {
                AlertDialog.Builder(this)
                    .setTitle("Location permission needed")
                    .setMessage("Mile Tracker needs precise location to measure miles with GPS. " +
                        "Please allow location, choosing Precise and While using the app.")
                    .setPositiveButton("Open settings") { _, _ ->
                        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            android.net.Uri.fromParts("package", packageName, null)))
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        store = Store(this)

        vehicleSpinner = findViewById(R.id.vehicleSpinner)
        purposeSpinner = findViewById(R.id.purposeSpinner)
        startStop = findViewById(R.id.startStopButton)
        stateText = findViewById(R.id.stateText)
        speedText = findViewById(R.id.speedText)
        tripText = findViewById(R.id.tripText)
        timeText = findViewById(R.id.timeText)
        odometerText = findViewById(R.id.odometerText)
        gpsText = findViewById(R.id.gpsText)

        purposeSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, purposes)
        purposeSpinner.setSelection(store.lastPurpose.coerceIn(0, purposes.size - 1))
        purposeSpinner.onItemSelectedListener = simpleListener { pos -> store.lastPurpose = pos }

        vehicleSpinner.onItemSelectedListener = simpleListener { pos ->
            if (pos in vehicles.indices) {
                store.selectedVehicleId = vehicles[pos].id
                refresh()
            }
        }

        startStop.setOnClickListener {
            if (TrackerState.tracking) {
                TrackingService.stop(this)
            } else {
                onStartPressed()
            }
        }
        findViewById<Button>(R.id.readStatusButton).setOnClickListener {
            it.announceForAccessibility(statusSentence())
            stateText.text = statusSentence()
        }
        findViewById<Button>(R.id.vehiclesButton).setOnClickListener {
            startActivity(Intent(this, VehiclesActivity::class.java))
        }
        findViewById<Button>(R.id.tripsButton).setOnClickListener {
            startActivity(Intent(this, TripsActivity::class.java))
        }

        val kmSwitch = findViewById<MaterialSwitch>(R.id.kmSwitch)
        kmSwitch.isChecked = store.useKm
        kmSwitch.setOnCheckedChangeListener { _, c -> store.useKm = c; updateSpeakLabel(); refresh() }
        val speakSwitch = findViewById<MaterialSwitch>(R.id.speakSwitch)
        speakSwitch.isChecked = store.speakEachUnit
        speakSwitch.setOnCheckedChangeListener { _, c -> store.speakEachUnit = c }
        val screenSwitch = findViewById<MaterialSwitch>(R.id.screenSwitch)
        screenSwitch.isChecked = store.keepScreenOn
        screenSwitch.setOnCheckedChangeListener { _, c -> store.keepScreenOn = c; refresh() }
        updateSpeakLabel()
    }

    private fun updateSpeakLabel() {
        findViewById<MaterialSwitch>(R.id.speakSwitch).text =
            "Speak distance out loud every " + Units.unitName(store.useKm, false)
    }

    override fun onResume() {
        super.onResume()
        loadVehicles()
        TrackerState.addListener(listener)
        // If a trip was interrupted (phone restarted the app), pick it back up.
        if (!TrackerState.tracking && store.activeTrip() != null && hasLocationPermission()) {
            ContextCompat.startForegroundService(this, Intent(this, TrackingService::class.java))
        }
        refresh()
        if (vehicles.isEmpty()) promptFirstVehicle()
    }

    override fun onPause() {
        TrackerState.removeListener(listener)
        super.onPause()
    }

    private fun loadVehicles() {
        vehicles = store.vehicles()
        val names = if (vehicles.isEmpty()) listOf("No vehicles yet") else vehicles.map { it.displayName() }
        vehicleSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        val sel = vehicles.indexOfFirst { it.id == store.selectedVehicleId }
        if (sel >= 0) vehicleSpinner.setSelection(sel)
        else if (vehicles.isNotEmpty()) store.selectedVehicleId = vehicles[0].id
    }

    private fun promptFirstVehicle() {
        AlertDialog.Builder(this)
            .setTitle("Add your first vehicle")
            .setMessage("To start tracking miles, add a vehicle. You can add as many as you like and switch between them.")
            .setPositiveButton("Add vehicle") { _, _ ->
                startActivity(Intent(this, EditVehicleActivity::class.java))
            }
            .setNegativeButton("Later", null)
            .show()
    }

    private fun currentVehicle(): Vehicle? =
        if (TrackerState.tracking) store.vehicle(TrackerState.vehicleId)
        else store.vehicle(store.selectedVehicleId)

    private fun refresh() {
        val km = store.useKm
        val tracking = TrackerState.tracking
        val v = currentVehicle()

        startStop.text = getString(if (tracking) R.string.stop_trip else R.string.start_trip)
        vehicleSpinner.isEnabled = !tracking
        purposeSpinner.isEnabled = !tracking

        if (lastTracking != null && lastTracking != tracking) {
            stateText.text = if (tracking) "Trip started. Tracking ${v?.displayName() ?: ""}."
                             else "Trip stopped and saved."
        } else if (lastTracking == null) {
            stateText.text = if (tracking) "Trip in progress." else "Ready. Press Start trip when you begin driving."
        }
        lastTracking = tracking

        val speed = Units.speed(TrackerState.speedMps, km)
        speedText.text = "%.0f %s".format(speed, Units.speedShort(km))
        speedText.contentDescription = "Current speed %.0f %s".format(speed, Units.speedUnit(km))

        val trip = Units.distance(TrackerState.tripMeters, km)
        tripText.text = "%.2f %s".format(trip, Units.shortUnit(km))
        tripText.contentDescription = "Trip distance %.2f %s".format(trip, Units.unitName(km))

        val elapsed = if (tracking) System.currentTimeMillis() - TrackerState.startMillis else 0L
        timeText.text = Units.duration(elapsed)
        timeText.contentDescription = "Trip time " + Units.durationSpoken(elapsed)

        val odoMeters = (v?.odometerMeters ?: 0.0) + if (tracking) TrackerState.tripMeters else 0.0
        val odo = Units.distance(odoMeters, km)
        odometerText.text = "%,.1f %s".format(odo, Units.shortUnit(km))
        odometerText.contentDescription = "Odometer %,.1f %s".format(odo, Units.unitName(km))

        gpsText.text = TrackerState.gpsDescription()
        gpsText.contentDescription = "GPS signal " + TrackerState.gpsDescription()

        if (tracking && store.keepScreenOn) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun statusSentence(): String {
        val km = store.useKm
        val v = currentVehicle()
        if (!TrackerState.tracking) {
            val odo = Units.distance(v?.odometerMeters ?: 0.0, km)
            return "Not tracking. ${v?.displayName() ?: "No vehicle"} odometer %,.1f %s."
                .format(odo, Units.unitName(km))
        }
        val elapsed = System.currentTimeMillis() - TrackerState.startMillis
        return "Trip %.2f %s in %s. Speed %.0f %s. GPS %s.".format(
            Units.distance(TrackerState.tripMeters, km), Units.unitName(km),
            Units.durationSpoken(elapsed),
            Units.speed(TrackerState.speedMps, km), Units.speedUnit(km),
            TrackerState.gpsDescription())
    }

    private fun hasLocationPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    private fun onStartPressed() {
        if (vehicles.isEmpty()) { promptFirstVehicle(); return }
        val perms = mutableListOf<String>()
        if (!hasLocationPermission()) {
            perms.add(Manifest.permission.ACCESS_FINE_LOCATION)
            perms.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (perms.isNotEmpty() && !hasLocationPermission()) {
            permissionLauncher.launch(perms.toTypedArray())
            return
        }
        if (perms.isNotEmpty()) {
            // Only notifications missing: ask, but don't block the trip.
            permissionLauncher.launch(perms.toTypedArray())
            return
        }
        startTrip()
    }

    private fun startTrip() {
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            AlertDialog.Builder(this)
                .setTitle("Location is off")
                .setMessage("Turn on Location on your phone so GPS can measure your miles.")
                .setPositiveButton("Open location settings") { _, _ ->
                    startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                }
                .setNegativeButton("Cancel", null)
                .show()
            return
        }
        val v = store.vehicle(store.selectedVehicleId) ?: vehicles.firstOrNull() ?: return
        val purpose = purposes[purposeSpinner.selectedItemPosition.coerceIn(0, purposes.size - 1)]
        TrackingService.start(this, v.id, purpose)
    }

    private fun simpleListener(onPick: (Int) -> Unit) = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) = onPick(position)
        override fun onNothingSelected(parent: AdapterView<*>?) {}
    }
}
