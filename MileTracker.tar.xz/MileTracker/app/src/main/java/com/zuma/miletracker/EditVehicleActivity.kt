package com.zuma.miletracker

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class EditVehicleActivity : AppCompatActivity() {

    companion object { const val EXTRA_ID = "id" }

    private lateinit var store: Store
    private lateinit var yearSpinner: Spinner
    private lateinit var makeSpinner: Spinner
    private lateinit var modelSpinner: Spinner
    private lateinit var customMake: EditText
    private lateinit var customModel: EditText
    private lateinit var modelStatus: TextView
    private lateinit var nickname: EditText
    private lateinit var odometer: EditText

    private val years = VehicleCatalog.years()
    private var makes: List<String> = emptyList()
    private var models: List<String> = emptyList()
    private var existing: Vehicle? = null
    private var wantedMake: String? = null
    private var wantedModel: String? = null
    private var lookupToken = 0
    private val main = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_vehicle)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        store = Store(this)

        yearSpinner = findViewById(R.id.yearSpinner)
        makeSpinner = findViewById(R.id.makeSpinner)
        modelSpinner = findViewById(R.id.modelSpinner)
        customMake = findViewById(R.id.customMake)
        customModel = findViewById(R.id.customModel)
        modelStatus = findViewById(R.id.modelStatus)
        nickname = findViewById(R.id.nickname)
        odometer = findViewById(R.id.odometer)

        val km = store.useKm
        findViewById<TextView>(R.id.odoLabel).text = "Current odometer reading in " + Units.unitName(km)
        odometer.hint = "Odometer in " + Units.unitName(km)

        existing = store.vehicle(intent.getStringExtra(EXTRA_ID))
        title = if (existing == null) "Add vehicle" else "Edit vehicle"

        yearSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, years.map { it.toString() })

        existing?.let { v ->
            wantedMake = v.make
            wantedModel = v.model
            nickname.setText(v.nickname)
            odometer.setText("%.1f".format(java.util.Locale.US, Units.distance(v.odometerMeters, km)))
            val yi = years.indexOf(v.year)
            if (yi >= 0) yearSpinner.setSelection(yi)
            findViewById<Button>(R.id.deleteButton).visibility = View.VISIBLE
        } ?: run {
            // Default to 10 years ago, a common age.
            val yi = years.indexOf(VehicleCatalog.LAST_YEAR - 10)
            if (yi >= 0) yearSpinner.setSelection(yi)
        }

        yearSpinner.onItemSelectedListener = picker { loadMakes() }
        makeSpinner.onItemSelectedListener = picker { onMakeChosen() }
        modelSpinner.onItemSelectedListener = picker {
            val m = models.getOrNull(modelSpinner.selectedItemPosition)
            customModel.visibility = if (m == VehicleCatalog.OTHER) View.VISIBLE else View.GONE
        }

        findViewById<Button>(R.id.saveButton).setOnClickListener { save() }
        findViewById<Button>(R.id.deleteButton).setOnClickListener { confirmDelete() }
        loadMakes()
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }

    private fun year(): Int = years[yearSpinner.selectedItemPosition.coerceIn(0, years.size - 1)]

    private fun loadMakes() {
        val current = wantedMake ?: makes.getOrNull(makeSpinner.selectedItemPosition)
        makes = VehicleCatalog.makesFor(year())
        // If editing a vehicle with a make that isn't in the list, keep it selectable.
        if (current != null && current != VehicleCatalog.OTHER && makes.none { it.equals(current, true) }
            && wantedMake != null) {
            makes = listOf(current) + makes
        }
        makeSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, makes)
        val idx = makes.indexOfFirst { it.equals(current, true) }
        if (idx >= 0) makeSpinner.setSelection(idx)
        onMakeChosen()
    }

    private fun onMakeChosen() {
        val make = makes.getOrNull(makeSpinner.selectedItemPosition) ?: return
        if (make == VehicleCatalog.OTHER) {
            customMake.visibility = View.VISIBLE
            customModel.visibility = View.VISIBLE
            setModels(listOf(VehicleCatalog.OTHER))
            modelStatus.text = "Type the make and model below."
            return
        }
        customMake.visibility = View.GONE
        val y = year()
        val builtIn = VehicleCatalog.modelsFor(make, y)
        val cached = store.cachedModels(make, y)
        setModels(merge(cached ?: builtIn, builtIn))
        if (cached != null) {
            modelStatus.text = "${models.size - 1} models for $y $make."
            return
        }
        modelStatus.text = "Showing ${builtIn.size} common models. Checking online for the full list."
        val token = ++lookupToken
        Thread {
            val online = VehicleCatalog.fetchOnline(make, y)
            main.post {
                if (token != lookupToken || isFinishing) return@post
                if (online != null) {
                    store.cacheModels(make, y, online)
                    setModels(merge(online, builtIn))
                    modelStatus.text = "Full list loaded: ${models.size - 1} models for $y $make."
                } else {
                    modelStatus.text = "Couldn't reach the online list. Showing ${builtIn.size} common models. " +
                        "Choose Other to type a model."
                }
            }
        }.start()
    }

    private fun merge(primary: List<String>, extra: List<String>): List<String> {
        val set = sortedSetOf<String>(String.CASE_INSENSITIVE_ORDER)
        set.addAll(primary)
        set.addAll(extra)
        return set.toList()
    }

    private fun setModels(list: List<String>) {
        val previous = wantedModel ?: models.getOrNull(modelSpinner.selectedItemPosition)
        val full = list.filter { it != VehicleCatalog.OTHER }.toMutableList()
        if (wantedModel != null && full.none { it.equals(wantedModel, true) }) full.add(0, wantedModel!!)
        full.add(VehicleCatalog.OTHER)
        models = full
        modelSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, models)
        val idx = models.indexOfFirst { it.equals(previous, true) }
        if (idx >= 0) modelSpinner.setSelection(idx)
        val sel = models.getOrNull(modelSpinner.selectedItemPosition)
        customModel.visibility = if (sel == VehicleCatalog.OTHER) View.VISIBLE else View.GONE
    }

    private fun save() {
        wantedMake = null
        wantedModel = null
        val pickedMake = makes.getOrNull(makeSpinner.selectedItemPosition) ?: ""
        val make = if (pickedMake == VehicleCatalog.OTHER) customMake.text.toString().trim() else pickedMake
        val pickedModel = models.getOrNull(modelSpinner.selectedItemPosition) ?: ""
        val model = if (pickedModel == VehicleCatalog.OTHER) customModel.text.toString().trim() else pickedModel
        if (make.isEmpty()) { toast("Please enter the make."); customMake.requestFocus(); return }
        if (model.isEmpty()) { toast("Please enter the model."); customModel.requestFocus(); return }

        val odoText = odometer.text.toString().replace(",", "").trim()
        val odoUnits = if (odoText.isEmpty()) 0.0 else odoText.toDoubleOrNull()
        if (odoUnits == null || odoUnits < 0) { toast("Odometer must be a number."); odometer.requestFocus(); return }
        val km = store.useKm
        val meters = odoUnits * (if (km) METERS_PER_KM else METERS_PER_MILE)

        val v = existing?.copy() ?: Vehicle(Store.newId(), year(), make, model, "", meters)
        v.year = year()
        v.make = make
        v.model = model
        v.nickname = nickname.text.toString().trim()
        // Only overwrite odometer if the user actually changed the number.
        val old = existing
        if (old == null || "%.1f".format(java.util.Locale.US, Units.distance(old.odometerMeters, km)) != odoText) {
            v.odometerMeters = meters
        }
        store.upsertVehicle(v)
        if (old == null) store.selectedVehicleId = v.id
        toast("Saved ${v.displayName()}")
        finish()
    }

    private fun confirmDelete() {
        val v = existing ?: return
        AlertDialog.Builder(this)
            .setTitle("Delete ${v.displayName()}?")
            .setMessage("This also deletes all of this vehicle's trips.")
            .setPositiveButton("Delete") { _, _ ->
                if (TrackerState.tracking && TrackerState.vehicleId == v.id) {
                    toast("Stop the current trip first.")
                } else {
                    store.deleteVehicle(v.id)
                    toast("Deleted")
                    finish()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun picker(onPick: () -> Unit) = object : AdapterView.OnItemSelectedListener {
        private var first = true
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            // Skip the automatic callback when the screen first opens.
            if (first) { first = false; return }
            // After the user changes something, stop forcing the saved make/model.
            if (parent === yearSpinner || parent === makeSpinner) {
                if (parent === makeSpinner) wantedModel = null
                wantedMake = null
            }
            onPick()
        }
        override fun onNothingSelected(parent: AdapterView<*>?) {}
    }
}
