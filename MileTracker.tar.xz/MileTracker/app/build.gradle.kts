plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val runNumber = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()

android {
    namespace = "com.zuma.miletracker"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.zuma.miletracker"
        minSdk = 26
        targetSdk = 35
        versionCode = runNumber
        versionName = "1.0.$runNumber"
    }

    // The signing key is NOT stored in the repository. The GitHub workflow
    // writes it from the SIGNING_KEY secret and passes its location here.
    val keystorePath = System.getenv("KEYSTORE_FILE")
    val keystorePass = System.getenv("KEYSTORE_PASSWORD")
    val hasKey = !keystorePath.isNullOrBlank() && !keystorePass.isNullOrBlank()

    signingConfigs {
        if (hasKey) {
            create("release") {
                storeFile = file(keystorePath!!)
                storePassword = keystorePass
                keyAlias = "miletracker"
                keyPassword = keystorePass
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            if (hasKey) signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
    buildFeatures {
        viewBinding = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
}
